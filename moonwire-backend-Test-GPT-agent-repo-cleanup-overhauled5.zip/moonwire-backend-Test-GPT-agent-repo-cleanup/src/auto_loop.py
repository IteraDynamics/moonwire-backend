"""
src/auto_loop.py
------------------

Thin wrapper around the production inference loop.  We place the
implementation in `scripts/auto_loop.py` so it can be invoked both via
`python src/auto_loop.py` and `python scripts/auto_loop.py`.  This file
simply forwards any command‑line arguments to the `scripts.auto_loop`
module.
"""
from __future__ import annotations
import sys
import pathlib
import sys

# Ensure the repository root is on sys.path so that `scripts.auto_loop`
# can be imported regardless of working directory.
ROOT = pathlib.Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))

from scripts.auto_loop import main


if __name__ == "__main__":
    # Forward command line arguments to scripts.auto_loop.main()
    main()