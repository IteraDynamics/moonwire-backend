#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from scripts.ml.data_loader import load_prices
from scripts.ml.backtest import run_backtest


def _load_predictions(path: Path) -> pd.DataFrame:
    """Load predictions from CSV or JSONL. Expects columns ts and p_long."""
    if not path.exists():
        raise FileNotFoundError(f"Predictions file {path} not found")
    if path.suffix.lower() == '.csv':
        df = pd.read_csv(path)
    else:
        # assume JSONL
        rows = [json.loads(ln) for ln in path.read_text().splitlines() if ln.strip()]
        df = pd.DataFrame(rows)
    # Normalize column names
    if 'p_long' not in df.columns:
        for c in ('prob_long', 'prob', 'p'):
            if c in df.columns:
                df = df.rename(columns={c: 'p_long'})
                break
    return df[['ts', 'p_long']]


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run backtest on prediction probabilities and write summary artifacts."
    )
    parser.add_argument('--symbol', required=True, help='Symbol to backtest (e.g. BTC)')
    parser.add_argument(
        '--pred-path', required=True, type=Path, help='Path to predictions CSV/JSONL with columns ts,p_long'
    )
    parser.add_argument(
        '--lookback-days', type=int, default=180, help='Number of days of historical price data to fetch'
    )
    parser.add_argument(
        '--conf-min', type=float, default=0.6, help='Minimum probability to trigger a trade'
    )
    parser.add_argument(
        '--debounce-min', type=int, default=30, help='Minimum minutes between trades'
    )
    parser.add_argument(
        '--horizon-h', type=int, default=1, help='Trade horizon in hours'
    )
    parser.add_argument(
        '--fees-bps', type=float, default=1.0, help='Transaction fee basis points per trade'
    )
    parser.add_argument(
        '--slippage-bps', type=float, default=2.0, help='Slippage basis points per trade'
    )
    parser.add_argument(
        '--out-dir', type=Path, default=Path('artifacts'), help='Output directory for metrics and equity curve'
    )
    args = parser.parse_args()

    # Load predictions and prices
    pred_df = _load_predictions(args.pred_path)
    prices_map = load_prices([args.symbol], lookback_days=args.lookback_days)
    price_df = prices_map.get(args.symbol.upper())

    # Run backtest
    res = run_backtest(
        pred_df,
        price_df,
        args.conf_min,
        args.debounce_min,
        args.horizon_h,
        fees_bps=args.fees_bps,
        slippage_bps=args.slippage_bps,
        symbol=args.symbol.upper(),
    )

    # Ensure output directory exists
    outdir = args.out_dir
    outdir.mkdir(parents=True, exist_ok=True)

    # Write metrics JSON
    metrics_path = outdir / 'bt_metrics.json'
    with metrics_path.open('w', encoding='utf-8') as f:
        json.dump(res.get('metrics', {}), f, indent=2)

    # Write trades JSONL
    trades_path = outdir / 'bt_trades.jsonl'
    trades = res.get('trades', [])
    with trades_path.open('w', encoding='utf-8') as f:
        for t in trades:
            # t may be dataclass or dict
            if hasattr(t, '__dict__'):
                d = {
                    k: (str(v) if hasattr(v, 'isoformat') else v) for k, v in t.__dict__.items()
                }
            else:
                d = t
            f.write(json.dumps(d) + "\n")

    # Write equity curve JSONL
    equity_path = outdir / 'bt_equity_curve.jsonl'
    equity = res.get('equity', [])
    with equity_path.open('w', encoding='utf-8') as f:
        for ts, eq in equity:
            f.write(json.dumps({'ts': str(ts), 'equity': eq}) + "\n")

    print(
        f"Backtest complete. Metrics: {metrics_path}, trades: {trades_path}, equity curve: {equity_path}"
    )


if __name__ == '__main__':
    main()