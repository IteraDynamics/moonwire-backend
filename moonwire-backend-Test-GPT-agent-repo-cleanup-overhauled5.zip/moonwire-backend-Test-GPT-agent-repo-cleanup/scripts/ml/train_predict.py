# scripts/ml/train_predict.py
from __future__ import annotations
import os, json, pathlib, re
import numpy as np
import pandas as pd
from typing import Dict, List
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from .utils import ensure_dirs, env_str, env_int, env_float, to_list, save_json
from .data_loader import load_prices
from .feature_builder import build_features
import joblib
from .labeler import label_next_horizon
from .splitter import walk_forward_splits
from .model_runner import train_model, predict_proba
from .tuner import tune_thresholds

ROOT = pathlib.Path(".").resolve()

# --- optional provenance (no-op if module not present)
try:
    from ._provenance import detect_provenance  # optional
except Exception:
    detect_provenance = None

def _write_provenance(prices_map, symbols, lookback_days):
    """
    Always write artifacts/data_provenance.json.
    - If detect_provenance exists, try (prices_map, symbols) first, then kwargs.
    - On any error, write a minimal payload with the error string so CI still uploads.
    """
    out = ROOT / "artifacts" / "data_provenance.json"
    out.parent.mkdir(parents=True, exist_ok=True)

    base = {
        "symbols": symbols,
        "lookback_days": int(lookback_days),
        "env": {
            "MW_OFFLINE_DEMO": os.getenv("MW_OFFLINE_DEMO"),
            "MW_DEMO": os.getenv("MW_DEMO"),
            "DEMO_MODE": os.getenv("DEMO_MODE"),
            "MW_BRANCH": os.getenv("MW_BRANCH"),
        },
    }

    payload = None
    if callable(detect_provenance):
        try:
            # Try simple positional signature
            try:
                payload = detect_provenance(prices_map, symbols)
            except TypeError:
                # Fallback: keyword signature
                payload = detect_provenance(
                    prices=prices_map,
                    symbols=symbols,
                    lookback_days=lookback_days,
                    env=base["env"],
                )
        except Exception as e:
            base["error"] = f"{type(e).__name__}: {e}"
    else:
        base["error"] = "provenance_module_missing"

    to_write = {**base, **(payload or {})}
    with out.open("w", encoding="utf-8") as f:
        json.dump(to_write, f, indent=2, sort_keys=True, default=str)
    print(f"[provenance] wrote {out}")


def _feature_matrix(df: pd.DataFrame):
    """
    Construct the feature matrix and target vector for model training.

    The set of features includes both price‑derived indicators and optional
    social/cross‑origin metrics.  When MW_CROSS_ORIGIN_ENABLED=1, additional
    columns such as reddit_market_corr and reddit_market_lag will be present
    in the DataFrame.  We dynamically include any numeric columns not starting
    with 'ts' or 'y_' to ensure new engineered features are automatically
    consumed without modifying this function.
    """
    # Base feature list
    base_cols = ["r_1h", "r_3h", "r_6h", "vol_6h", "atr_14h", "sma_gap", "high_vol", "social_score"]
    # Auto‑extend with any cross‑origin features present
    extra_cols = [c for c in df.columns if c not in base_cols and c not in {"ts", "y_long"} and df[c].dtype != object]
    feature_cols = base_cols + extra_cols
    X = df[feature_cols].values.astype(float)
    y = df["y_long"].values.astype(int)
    return X, y, feature_cols

def _plots_roc_pr_placeholder():
    # Simple placeholder figure (we're not computing ROC/PR here to keep deps minimal)
    (ROOT / "artifacts").mkdir(parents=True, exist_ok=True)
    plt.figure()
    plt.title("ML ROC/PR (placeholder)")
    plt.plot([0,1],[0,1])
    plt.savefig(ROOT/"artifacts/ml_roc_pr_curve.png")
    plt.close()

def _plot_equity_placeholder():
    (ROOT / "artifacts").mkdir(parents=True, exist_ok=True)
    plt.figure()
    plt.title("Backtest Equity (placeholder)")
    plt.plot([0,1,2,3],[1,1.01,0.99,1.02])
    plt.savefig(ROOT/"artifacts/bt_equity_curve.png")
    plt.close()

def _maybe_fail_on_demo(prov: dict):
    """
    Optional guard. OFF by default.
    Enable by setting:
      MW_FAIL_ON_DEMO=1
      MW_BRANCH=<current branch name> (CI: ${{ github.ref_name }})
      MW_PROTECTED_PATTERN='^main$'   (regex; defaults to ^main$)
    If provenance indicates demo + branch matches protected pattern -> raise.
    """
    if not prov or not isinstance(prov, dict):
        return
    if str(os.getenv("MW_FAIL_ON_DEMO", "0")).strip() not in {"1", "true", "TRUE"}:
        return

    branch = os.getenv("MW_BRANCH", "")
    pattern = os.getenv("MW_PROTECTED_PATTERN", r"^main$")
    is_protected = bool(re.search(pattern, branch or ""))

    # We treat these flags as "demo" hints; adjust to your _provenance payload.
    is_demo = bool(prov.get("demo", False)) or str(prov.get("source", "")).lower().startswith("demo")

    if is_protected and is_demo:
        raise RuntimeError(
            f"Provenance indicates demo data on protected branch '{branch}'. "
            f"Set MW_FAIL_ON_DEMO=0 to bypass, or switch to real data."
        )

def main():
    ensure_dirs()

    symbols = to_list(env_str("MW_ML_SYMBOLS", "BTC,ETH,SOL"))
    lookback_days = env_int("MW_ML_LOOKBACK_DAYS", 180)
    model_type = env_str("MW_ML_MODEL", "logreg")
    train_days = env_int("MW_TRAIN_DAYS", 60)
    test_days = env_int("MW_TEST_DAYS", 30)
    horizon_h = env_int("MW_HORIZON_H", 1)

    # --- Load + build features (unchanged behavior) ---
    prices = load_prices(symbols, lookback_days=lookback_days)
    feats = build_features(prices)
    
    _write_provenance(prices, symbols, lookback_days)

    pred_dfs: Dict[str, pd.DataFrame] = {}
    manifest = {
        "model_type": model_type,
        "symbols": symbols,
        "lookback_days": lookback_days,
        # The feature list will be updated below once computed
        "feature_list": [],
        "train_days": train_days,
        "test_days": test_days,
        "horizon_h": horizon_h,
        "fold_metrics": [],
    }

    for sym in symbols:
        df = label_next_horizon(feats[sym], horizon_h=horizon_h)
        X, y, feature_cols = _feature_matrix(df)
        # Store feature list only once (they are identical across symbols)
        if not manifest["feature_list"]:
            manifest["feature_list"] = feature_cols

        # walk-forward; keep last fold predictions
        preds = np.zeros(len(df))
        fold_ix = 0
        for tr_ix, te_ix in walk_forward_splits(df, n_splits=3, train_days=train_days, test_days=test_days):
            if len(tr_ix) < 10 or len(te_ix) < 5:  # tiny safety
                continue
            m = train_model(X[tr_ix], y[tr_ix], model_type=model_type)
            p = predict_proba(m, X[te_ix])
            preds[te_ix] = p
            # simple fold metric
            manifest["fold_metrics"].append({
                "symbol": sym,
                "fold": fold_ix,
                "train_len": int(len(tr_ix)),
                "test_len": int(len(te_ix)),
                "pred_mean": float(p.mean()),
            })
            fold_ix += 1

        pred_dfs[sym] = pd.DataFrame({"ts": df["ts"], "p_long": preds})

        # Train a final model on all available data for this symbol and
        # persist it to the models directory.  This allows downstream
        # inference (e.g. auto_loop.py) to load the trained model instead
        # of retraining on the fly.  We fit on the full feature matrix
        # without walk‑forward splits to maximize training data.
        try:
            full_model = train_model(X, y, model_type=model_type)
            out_path = ROOT / "models" / f"model_{sym}.joblib"
            out_path.parent.mkdir(parents=True, exist_ok=True)
            joblib.dump(full_model, out_path)
            print(f"[train_predict] saved final model for {sym} to {out_path}")
        except Exception as e:
            print(f"[train_predict] warning: failed to save model for {sym}: {e}")

    # --- tune thresholds (unchanged) ---
    best = tune_thresholds(pred_dfs, prices)
    save_json("models/backtest_summary.json", {"aggregate": best["agg"], "per_symbol": best["per_symbol"]})
    save_json("models/ml_model_manifest.json", manifest)

    # --- placeholder plots (unchanged) ---
    _plots_roc_pr_placeholder()
    _plot_equity_placeholder()

    # Placeholder for future governance integration: at this point the
    # training pipeline finishes with model persistence and threshold tuning.
    # A subsequent governance pass (promotion/rollback, drift response) can be
    # orchestrated via separate scripts (e.g., scripts/governance/drift_response.py
    # or scripts/governance/retrain_automation.py) once those components are
    # wired into the live pipeline.  This file does not automatically invoke
    # governance actions to avoid unintended side effects during development.

if __name__ == "__main__":
    main()