# scripts/ml/feature_builder.py
from __future__ import annotations
import os
import json
import re
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, List, Optional

import pandas as pd
import numpy as np


# ----------------------------
# Helpers (timestamps & parsing)
# ----------------------------
_ISO = "%Y-%m-%dT%H:%M:%SZ"
_RE_BTC = re.compile(r"\b(bitcoin|btc)\b", re.I)
_RE_ETH = re.compile(r"\b(ethereum|eth)\b", re.I)
_RE_SOL = re.compile(r"\b(solana|sol)\b", re.I)

def _to_utc(dt_str: str) -> datetime:
    """Parse tolerant ISO string ('Z' or '+00:00') → aware UTC datetime."""
    return datetime.fromisoformat(dt_str.replace("Z", "+00:00")).astimezone(timezone.utc)

def _to_utc_ts(x) -> pd.Timestamp:
    """
    Convert a variety of inputs (datetime, pd.Timestamp, str) into a UTC-aware
    pandas.Timestamp. If naive → localize UTC; if tz-aware → convert to UTC.
    """
    t = pd.Timestamp(x)
    if t.tzinfo is None:
        t = t.tz_localize("UTC")
    else:
        t = t.tz_convert("UTC")
    return t

def _as_hour_series(df: pd.DataFrame) -> Optional[pd.Series]:
    """
    Return a UTC hourly bucket series aligned to df rows.
    Prefers 'ts' column; falls back to datetime-like index.
    """
    if "ts" in df.columns:
        ts = pd.to_datetime(df["ts"], utc=True, errors="coerce")
    else:
        idx = pd.to_datetime(df.index, utc=True, errors="coerce")
        ts = pd.Series(idx, index=df.index)
    if ts.isna().all():
        return None
    # use lowercase 'h' to avoid FutureWarning
    return ts.dt.floor("h")

def _env_bool(name: str, default: bool = False) -> bool:
    v = os.getenv(name)
    if v is None:
        return default
    return str(v).strip().lower() in {"1", "true", "yes", "y", "on"}


# ----------------------------
# Social score (optional/gated)
# ----------------------------
def _load_jsonl_safe(path: Path) -> List[dict]:
    try:
        if not path.exists():
            return []
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        return [json.loads(ln) for ln in lines if ln.strip()]
    except Exception:
        return []

def _symbol_match_from_row(sym: str, row: dict) -> bool:
    """
    Cheap symbol mapping based on subreddit/keywords/text (no hard deps).
    - BTC: subreddit 'Bitcoin' OR title/text hits 'bitcoin|btc'
    - ETH: subreddit 'ethtrader' OR hits 'ethereum|eth'
    - SOL: subreddit 'Solana' OR hits 'solana|sol'
    """
    sub = (row.get("subreddit") or "").lower()
    title = (row.get("title") or row.get("text") or "")
    if sym == "BTC":
        if sub == "bitcoin" or _RE_BTC.search(title):
            return True
    elif sym == "ETH":
        if sub == "ethtrader" or _RE_ETH.search(title):
            return True
    elif sym == "SOL":
        if sub == "solana" or _RE_SOL.search(title):
            return True
    return False

def _collect_hour_counts_for_symbol(sym: str, look_hours: List[pd.Timestamp]) -> Dict[pd.Timestamp, int]:
    """
    Build per-hour post/tweet counts within the look window for a symbol.
    Uses:
      - logs/social_reddit.jsonl
      - logs/social_twitter.jsonl
    Falls back to empty counts if files missing.
    """
    logs_dir = Path("logs")
    r_rows = _load_jsonl_safe(logs_dir / "social_reddit.jsonl")
    t_rows = _load_jsonl_safe(logs_dir / "social_twitter.jsonl")

    # Window bounds (inclusive) from feature hours
    if not look_hours:
        return {}

    # tz-safe + lowercase hour
    start_h = _to_utc_ts(min(look_hours)).floor("h")
    end_h   = _to_utc_ts(max(look_hours)).floor("h") + pd.Timedelta(hours=1)

    buckets: Dict[pd.Timestamp, int] = {}

    def bump(dt: datetime):
        # convert to UTC-aware Timestamp and bucket to hour (lowercase 'h')
        h = _to_utc_ts(dt).floor("h")
        if h < start_h or h >= end_h:
            return
        buckets[h] = buckets.get(h, 0) + 1

    # Reddit rows: expect created_utc + optional mode/source fields
    for r in r_rows:
        try:
            if not _symbol_match_from_row(sym, r):
                continue
            ciso = r.get("created_utc")
            if not ciso:
                continue
            bump(_to_utc(ciso))
        except Exception:
            continue

    # Twitter rows: created_utc present in lite ingest
    for r in t_rows:
        try:
            if not _symbol_match_from_row(sym, r):
                continue
            ciso = r.get("created_utc")
            if not ciso:
                continue
            bump(_to_utc(ciso))
        except Exception:
            continue

    return buckets

def _normalize_counts_to_score(hrs: List[pd.Timestamp], counts: Dict[pd.Timestamp, int]) -> pd.Series:
    """
    Map hourly integer counts → [0,1] score with a neutral prior (0.5) and safety for flat series.
    """
    xs = [int(counts.get(h, 0)) for h in hrs]
    if len(xs) == 0:
        return pd.Series([], dtype=float)
    mn, mx = min(xs), max(xs)
    if mx == mn:
        # all same -> return neutral 0.5
        return pd.Series([0.5] * len(xs), index=hrs, dtype=float)
    # min/max normalize with a soft prior (pull towards 0.5 a bit)
    raw = [(x - mn) / (mx - mn) for x in xs]
    score = [0.75 * r + 0.25 * 0.5 for r in raw]  # shrink towards 0.5
    return pd.Series(score, index=hrs, dtype=float)

def _attach_social_score(df: pd.DataFrame, sym: str) -> pd.DataFrame:
    """
    Attach a social sentiment score aligned to hourly buckets.  The score
    reflects the relative volume of posts/tweets matching the symbol within
    each hour.  When social fusion is disabled (MW_SOCIAL_FUSION=off) the
    score is fixed at 0.5 so that the model behaves as price‑only.

    Environment:
      MW_SOCIAL_FUSION: "on" (default) enables social features; "off" disables.
    """
    # Determine whether to fuse social signals into the model.  Default is on
    # unless explicitly set to off.  Accept multiple truthy values for
    # backwards compatibility (1, true, yes, on).
    fusion = os.getenv("MW_SOCIAL_FUSION", "on").strip().lower()
    enabled = fusion in {"on", "1", "true", "yes", "y"}
    df = df.copy()
    df["social_score"] = 0.5
    if not enabled:
        return df

    # Need hourly buckets from df
    hours = _as_hour_series(df)
    if hours is None:
        return df  # can't align -> stay neutral

    # Build score series for the set of hours present
    unique_hours = sorted(pd.Series(hours).dropna().unique())
    hour_counts = _collect_hour_counts_for_symbol(sym, unique_hours)
    hour_scores = _normalize_counts_to_score(unique_hours, hour_counts)

    # Map row-wise
    df["social_score"] = [float(hour_scores.get(h, 0.5)) for h in hours]
    return df


# ----------------------------
# Price-derived features
# ----------------------------
# --- Cross‑origin correlation features ---
# We bring in a few lightweight helpers from the cross_origin_analysis module.  These
# functions compute lagged correlations between the social post counts (Reddit,
# Twitter) and the primary market returns (BTC) over a rolling 72h window.  The
# resulting metrics are constant over the dataset and therefore do not leak
# information from the future.  They serve as high‑level descriptors of how
# strongly (and in which direction) each social source is leading or lagging the
# market.  These metrics are attached to every feature row below.
try:
    # Lazy imports guarded so that importing this module does not incur heavy
    # dependencies unless MW_CROSS_ORIGIN_ENABLED is set.  The cross_origin
    # analysis functions live in the summary_sections package and are typically
    # used for CI reporting.  We reuse them here for feature engineering.
    from scripts.summary_sections.cross_origin_analysis import (
        LeadLagConfig,
        _load_series_from_logs_or_models,
        _cross_corr_lag,
    )
    _CROSS_IMPORT_OK = True
except Exception:
    # In case the summary module is missing, we default to no cross features.
    _CROSS_IMPORT_OK = False

_cross_origin_metrics_cache: Optional[Dict[str, float]] = None

def _compute_cross_origin_metrics() -> Dict[str, float]:
    """
    Compute simple cross‑origin correlation and lead/lag metrics based on the
    append‑only social and market logs.  The resulting dictionary contains
    numerical values for the correlation coefficient and lag (in hours) for
    each pair: reddit↔market, twitter↔market and reddit↔twitter.  If logs are
    missing or malformed, the metrics default to zeros.

    The computation is intentionally lightweight: it uses the same 72h window
    and ±12h shift as the CI summary, but runs only once per process and
    caches the result.  Because the values are constant across the entire
    feature DataFrame, they do not introduce look‑ahead bias.
    """
    global _cross_origin_metrics_cache
    if _cross_origin_metrics_cache is not None:
        return _cross_origin_metrics_cache
    # Default to zeros for all metrics
    metrics = {
        "reddit_market_corr": 0.0,
        "reddit_market_lag": 0,
        "twitter_market_corr": 0.0,
        "twitter_market_lag": 0,
        "reddit_twitter_corr": 0.0,
        "reddit_twitter_lag": 0,
    }
    # Only compute if cross imports succeeded and the gate is enabled
    enabled = _env_bool("MW_CROSS_ORIGIN_ENABLED", False)
    if not (_CROSS_IMPORT_OK and enabled):
        _cross_origin_metrics_cache = metrics
        return metrics
    try:
        cfg = LeadLagConfig(lookback_h=72, max_shift_h=12, n_perm=0)
        reddit, twitter, market = _load_series_from_logs_or_models(cfg)
        # Compute reddit↔market
        if reddit.size > 0 and market.size > 0:
            lag_rm, r_rm, _, _ = _cross_corr_lag(reddit, market, cfg.max_shift_h)
            metrics["reddit_market_corr"] = float(r_rm if np.isfinite(r_rm) else 0.0)
            metrics["reddit_market_lag"] = int(lag_rm)
        # Compute twitter↔market
        if twitter.size > 0 and market.size > 0:
            lag_tm, r_tm, _, _ = _cross_corr_lag(twitter, market, cfg.max_shift_h)
            metrics["twitter_market_corr"] = float(r_tm if np.isfinite(r_tm) else 0.0)
            metrics["twitter_market_lag"] = int(lag_tm)
        # Compute reddit↔twitter
        if reddit.size > 0 and twitter.size > 0:
            lag_rt, r_rt, _, _ = _cross_corr_lag(reddit, twitter, cfg.max_shift_h)
            metrics["reddit_twitter_corr"] = float(r_rt if np.isfinite(r_rt) else 0.0)
            metrics["reddit_twitter_lag"] = int(lag_rt)
    except Exception:
        # swallow any errors and keep defaults
        pass
    _cross_origin_metrics_cache = metrics
    return metrics


def _features_for_symbol(df: pd.DataFrame, sym: str) -> pd.DataFrame:
    df = df.copy()

    # basic returns
    df["ret_1h"] = df["close"].pct_change(1)
    df["r_1h"] = df["ret_1h"]
    df["r_3h"] = df["close"].pct_change(3)
    df["r_6h"] = df["close"].pct_change(6)

    # volatility
    df["vol_6h"] = df["ret_1h"].rolling(6).std()

    # ATR approx over 14h (true range on OHLC)
    tr = (df["high"] - df["low"]).abs()
    tr_prev_close = (df["high"] - df["close"].shift(1)).abs().combine(
        (df["low"] - df["close"].shift(1)).abs(), max
    )
    df["atr_14h"] = pd.concat([tr, tr_prev_close], axis=1).max(axis=1).rolling(14).mean()

    # momentum
    df["sma_6h"] = df["close"].rolling(6).mean()
    df["sma_24h"] = df["close"].rolling(24).mean()
    df["sma_gap"] = df["sma_6h"] / df["sma_24h"] - 1.0

    # regime flag
    thresh = df["vol_6h"].quantile(0.75)
    df["high_vol"] = (df["vol_6h"] > thresh).astype(int)

    # social (neutral by default; overwrite if gate enabled & logs exist)
    df = _attach_social_score(df, sym)

    # cross‑origin correlation metrics (optional)
    # These values are constant over the DataFrame and therefore safe from
    # leakage.  They capture whether Reddit/Twitter tend to lead the market and
    # how strong that relationship is.  To enable these features, set
    # MW_CROSS_ORIGIN_ENABLED=1 in the environment.  Defaults to off.
    metrics = _compute_cross_origin_metrics()
    for k, v in metrics.items():
        df[k] = float(v)

    # clean
    df = df.dropna().reset_index(drop=True)
    return df


def build_features(df_prices: Dict[str, pd.DataFrame]) -> Dict[str, pd.DataFrame]:
    """
    Price-only by default.
    If MW_SOCIAL_ENABLED=1 and social logs exist, attach aligned hourly social_score.
    """
    out: Dict[str, pd.DataFrame] = {}
    for sym, df in df_prices.items():
        out[sym] = _features_for_symbol(df, sym)
    return out