"""
scripts/auto_loop.py
----------------------

Continuous inference loop for MoonWire.  This script runs a simple
inference cycle at a configurable interval, loading the most recent
trained models and thresholds, fetching live market data, building
features (including optional social and cross‑origin metrics), and
emitting signals when the model confidence exceeds a threshold and
debounce period has elapsed.

Usage (environment variables):

  MW_LOOP_SYMBOLS       Comma‑separated list of symbols to monitor (default "BTC,ETH,SOL").
  MW_LOOP_INTERVAL_MIN  Minutes between inference cycles (default 60).
  MW_DEBOUNCE_MIN       Minimum minutes between signals per symbol (default 15).
  MW_SIGNAL_THRESHOLDS_FILE  Path to JSON thresholds file (default "models/signal_thresholds.json").
  MW_CROSS_ORIGIN_ENABLED    Enable cross‑origin correlation features (default 0).

This script should be run in a persistent environment (e.g., as a
background process or CRON job).  It deliberately avoids any
long‑running state: models and thresholds are re‑loaded on each
iteration so updates are picked up automatically.
"""
from __future__ import annotations
import argparse
import os
import json
import time
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional

import pandas as pd  # type: ignore
import numpy as np  # type: ignore

from scripts.market.coingecko_client import CoinGeckoClient
from scripts.ml.data_loader import load_prices
from scripts.ml.feature_builder import build_features
from scripts.ml.model_runner import predict_proba
import joblib

# signal logging (write to canonical JSONL)
try:
    from src.signal_log import write_signal
except Exception:
    # fallback: define a no‑op logger if src is unavailable during unit tests
    def write_signal(signal: Dict, path: Optional[str] = None) -> None:
        print(f"[auto_loop] signal: {json.dumps(signal)}")


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, default))
    except Exception:
        return default


def _env_list(name: str, default: str) -> List[str]:
    val = os.getenv(name)
    if not val:
        val = default
    return [s.strip().upper() for s in val.split(",") if s.strip()]


def _map_symbol_to_coingecko_id(sym: str) -> str:
    mapping = {
        "BTC": "bitcoin",
        "ETH": "ethereum",
        "SOL": "solana",
        "LTC": "litecoin",
    }
    return mapping.get(sym.upper(), sym.lower())


def _load_thresholds(path: str) -> Dict[str, float]:
    """
    Load per‑symbol confidence thresholds from a JSON file.  The tuner
    writes models/signal_thresholds.json with a shape like:

        {
          "params": { ... },
          "agg": { ... },
          "per_symbol": {
            "BTC": {"thr": 0.62, "debounce_min": 15},
            ...
          }
        }

    If the file is missing or malformed, default thresholds of 0.6 are
    returned for all symbols.
    """
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return {}
    # Flatten per_symbol dict if present
    per_symbol = data.get("per_symbol") or {}
    out: Dict[str, float] = {}
    for sym, cfg in per_symbol.items():
        thr = cfg.get("thr") or cfg.get("threshold") or cfg.get("conf_min")
        try:
            out[sym.upper()] = float(thr)
        except Exception:
            continue
    return out


def _load_models(symbols: List[str]) -> Dict[str, object]:
    """
    Load joblib models from the models directory.  Looks for files
    named model_<SYM>.joblib.  Models that fail to load are skipped.
    """
    models: Dict[str, object] = {}
    for sym in symbols:
        fname = f"models/model_{sym}.joblib"
        if not os.path.isfile(fname):
            continue
        try:
            models[sym] = joblib.load(fname)
        except Exception as e:
            print(f"[auto_loop] failed to load model for {sym}: {e}")
    return models


def _append_current_price(prices_df: pd.DataFrame, price: float) -> pd.DataFrame:
    """
    Append a new row representing the current market price to the price
    DataFrame.  We use the same price for open/high/low/close to avoid
    distortion.  The timestamp is set to now (UTC).  This helper returns
    a new DataFrame without modifying the original.
    """
    now_ts = pd.Timestamp(datetime.now(timezone.utc))
    row = {
        "ts": now_ts.isoformat().replace("+00:00", "Z"),
        "open": price,
        "high": price,
        "low": price,
        "close": price,
        "volume": 0.0,
    }
    df = prices_df.copy()
    df = df.append(row, ignore_index=True)
    return df


def main() -> None:
    # Parse optional CLI overrides
    parser = argparse.ArgumentParser(description="MoonWire continuous inference loop")
    parser.add_argument("--interval-min", type=float, default=None, help="Minutes between inference cycles (overrides MW_LOOP_INTERVAL_MIN)")
    parser.add_argument("--symbols", type=str, default=None, help="Comma‑separated list of symbols to monitor (overrides MW_LOOP_SYMBOLS)")
    parser.add_argument("--debounce-min", type=float, default=None, help="Minimum minutes between signals per symbol (overrides MW_DEBOUNCE_MIN)")
    parser.add_argument("--thresholds", type=str, default=None, help="Path to thresholds JSON file (overrides MW_SIGNAL_THRESHOLDS_FILE)")
    args, _ = parser.parse_known_args()

    # Determine symbols list: CLI → MW_LOOP_SYMBOLS env → fallback MW_ML_SYMBOLS
    sym_env = os.getenv("MW_LOOP_SYMBOLS") or os.getenv("MW_ML_SYMBOLS") or "BTC,ETH,SOL"
    symbols = _env_list("MW_LOOP_SYMBOLS", sym_env)
    if args.symbols:
        symbols = [s.strip().upper() for s in args.symbols.split(",") if s.strip()]

    # Determine inference interval in minutes: CLI → MW_LOOP_INTERVAL_MIN env → MW_BUCKET_MIN → default 60
    if args.interval_min is not None:
        interval_min = float(args.interval_min)
    else:
        interval_min = float(os.getenv("MW_LOOP_INTERVAL_MIN", os.getenv("MW_BUCKET_MIN", "60")))

    # Debounce: CLI → MW_DEBOUNCE_MIN env → MW_DEBOUNCE_MIN_DEFAULT env → fallback 30
    if args.debounce_min is not None:
        debounce_min = float(args.debounce_min)
    else:
        debounce_env = os.getenv("MW_DEBOUNCE_MIN") or os.getenv("MW_DEBOUNCE_MIN_DEFAULT") or "30"
        try:
            debounce_min = float(debounce_env)
        except Exception:
            debounce_min = 30.0

    # Thresholds file path: CLI → MW_SIGNAL_THRESHOLDS_FILE env → default
    thr_path = args.thresholds or os.getenv("MW_SIGNAL_THRESHOLDS_FILE", "models/signal_thresholds.json")

    # Propagate social fusion setting into MW_SOCIAL_ENABLED and MW_CROSS_ORIGIN_ENABLED
    fusion = os.getenv("MW_SOCIAL_FUSION", "on").strip().lower()
    if fusion in {"off", "0", "false"}:
        os.environ.setdefault("MW_SOCIAL_ENABLED", "0")
        os.environ.setdefault("MW_CROSS_ORIGIN_ENABLED", "0")
    else:
        os.environ.setdefault("MW_SOCIAL_ENABLED", "1")
        os.environ.setdefault("MW_CROSS_ORIGIN_ENABLED", "1")

    # Determine current model version from file if provided
    model_version_file = os.getenv("MW_CURRENT_VERSION_FILE")
    model_version = "unspecified"
    if model_version_file and os.path.isfile(model_version_file):
        try:
            with open(model_version_file, "r", encoding="utf-8") as f:
                model_version = f.read().strip() or model_version
        except Exception:
            pass

    # Tracking last signal timestamps to enforce debounce
    last_signal_ts: Dict[str, Optional[datetime]] = {sym: None for sym in symbols}

    cg = CoinGeckoClient()
    # Pre‑load static price histories (we update with current price each iteration)
    price_histories = load_prices(symbols, lookback_days=7)

    print(f"[auto_loop] starting loop for symbols {symbols} with interval {interval_min}m")
    # Import cross‑origin metrics helper once; will be invoked in loop
    from scripts.ml.feature_builder import _compute_cross_origin_metrics as _cross_metrics
    while True:
        # reload thresholds and models each iteration so updates are picked up
        thresholds = _load_thresholds(thr_path)
        models = _load_models(symbols)

        # Get latest cross‑origin metrics
        x_metrics = _cross_metrics()

        for sym in symbols:
            # Skip if no model available
            model = models.get(sym)
            if model is None:
                print(f"[auto_loop] no model loaded for {sym}, skipping")
                continue
            # Fetch live price
            coin_id = _map_symbol_to_coingecko_id(sym)
            try:
                data = cg.simple_price([coin_id], vs_currency="usd", include_24h_change=False)
                price = float(data[coin_id]["usd"])
            except Exception as e:
                print(f"[auto_loop] failed to fetch price for {sym}: {e}")
                continue
            # Build feature DF: update price history with latest tick
            df_prices = price_histories.get(sym)
            if df_prices is None or df_prices.empty:
                continue
            df_ext = _append_current_price(df_prices, price)
            feats_map = build_features({sym: df_ext})
            feats_df = feats_map[sym]
            if feats_df.empty:
                continue
            # Take the last row of features for inference
            row = feats_df.iloc[-1]
            # Build feature vector in the same order as training
            feature_cols = [c for c in feats_df.columns if c not in {"ts", "y_long"} and feats_df[c].dtype != object]
            X_row = row[feature_cols].values.reshape(1, -1).astype(float)
            # Predict probability of long
            try:
                p = predict_proba(model, X_row)[0]
            except Exception as e:
                print(f"[auto_loop] prediction error for {sym}: {e}")
                continue
            # Determine threshold; fallback to 0.6 if not found
            # Determine a base threshold: from per‑symbol thresholds file,
            # otherwise fall back to global default MW_CONF_MIN_DEFAULT (or 0.60)
            default_conf = float(os.getenv("MW_CONF_MIN_DEFAULT", "0.60"))
            base_thr = thresholds.get(sym.upper(), default_conf)
            # Adjust threshold based on global cross‑origin correlation
            # Use reddit↔market correlation as proxy; stronger positive
            # correlation lowers the threshold slightly.  You can refine this
            # heuristic as needed.  Clamp within [0.4, 0.9].
            corr = float(x_metrics.get("reddit_market_corr", 0.0))
            adj = 0.05 * abs(corr)
            thr = max(0.4, min(0.9, base_thr - adj))
            # Debounce check
            now_dt = datetime.now(timezone.utc)
            last_ts = last_signal_ts.get(sym)
            allow_emit = True
            if last_ts is not None:
                delta = (now_dt - last_ts).total_seconds() / 60.0
                if delta < debounce_min:
                    allow_emit = False
            if p >= thr and allow_emit:
                # Emit signal
                sig = {
                    "ts": now_dt.isoformat().replace("+00:00", "Z"),
                    "symbol": sym,
                    "confidence": float(p),
                    "price": float(price),
                    "source": "auto_loop",
                    "model_version": model_version,
                    "direction": "LONG",
                }
                try:
                    # Use SIGNALS_FILE env var if provided
                    out_path = os.getenv("SIGNALS_FILE")
                    write_signal(sig, path=out_path)  # type: ignore[arg-type]
                    last_signal_ts[sym] = now_dt
                    print(f"[auto_loop] emitted signal for {sym}: p={p:.3f} thr={thr:.3f}")
                except Exception as e:
                    print(f"[auto_loop] failed to write signal: {e}")
            # update the stored price history with the appended row for next iteration
            price_histories[sym] = df_ext
        # Sleep
        time.sleep(max(30, interval_min * 60))


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("[auto_loop] exiting on keyboard interrupt")